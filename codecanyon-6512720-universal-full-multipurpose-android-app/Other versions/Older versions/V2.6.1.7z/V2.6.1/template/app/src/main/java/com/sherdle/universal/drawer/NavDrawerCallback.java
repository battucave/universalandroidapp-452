package com.sherdle.universal.drawer;

public interface NavDrawerCallback {
    void onNavigationDrawerItemSelected(int position, NavItem item);
}
