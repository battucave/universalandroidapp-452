package com.sherdle.universal;

/**
 * This is an interface for fragments to easily request permissions
 */
public interface PermissionsFragment {

    String[] requiredPermissions();

}
